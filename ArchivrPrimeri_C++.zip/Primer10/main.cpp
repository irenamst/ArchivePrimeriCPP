#include <iostream>

using namespace std;
int f1 (int a);
double f1(double b);
int main()
{
    int a=0;
    double b=0.01;
    cout << "Hello world!" << endl;
    cout<<f1(a)<<"\n";
    cout<<f1(b)<<"\n";
    return 0;
}
int f1(int a){
 return a;
};
double f1(double a){
return a;
};
