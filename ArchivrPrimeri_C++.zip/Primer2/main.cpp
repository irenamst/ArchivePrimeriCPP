#include <iostream>

using namespace std;

int main()
{
    int i;
    float f;
    cout << "Enter an interger then a float ";
    cin>>i>>f;
    cout<<"i= "<<i<<" f= "<<f<<"\n";
    return 0;
}
