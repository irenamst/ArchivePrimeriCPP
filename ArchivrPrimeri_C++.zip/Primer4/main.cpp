/*
This is a multiline comment
Inside which //is nested a single-line comment.
Here is the end of the multiline comment.
*/
#include <iostream>

using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
