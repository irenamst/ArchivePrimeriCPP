#include "MyClass.h"

MyClass::MyClass()
{
    //ctor
}

MyClass::~MyClass()
{
    //dtor
}
