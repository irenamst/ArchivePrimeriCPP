#ifndef MYCLASS_H
#define MYCLASS_H


class MyClass
{
    int a;
    public:
        void set_a(int num);
        int get_a();
        MyClass();
        virtual ~MyClass();

    protected:

    private:
};

#endif // MYCLASS_H
