#include <iostream>

using namespace std;

int absolute(int n);
long absolute(long n);
double absolute(double n);

int main()
{
    cout << "Hello world!" << endl;
    cout<<"Abs value of -10:"<<absolute(-10)<<"\n";
    cout<<"Abs value of -10L:"<<absolute(-10L)<<"\n";
    cout<<"Abs value of -10.01:"<<absolute(-10.01)<<"\n";

    return 0;
}
int absolute(int n){
cout<<"In integer abs()\n";
return n<0 ? -n:n;
};
long absolute(long n){
cout<<"In long abs()\n";
return n<0 ? -n:n;
};
double absolute(double n){
cout<<"In double abs()\n";
return n<0 ? -n:n;
};
