#include <iostream>

using namespace std;

int main()
{
    cout << "This string is to the screen.\n";
    cout << 236.99;
    return 0;
}
